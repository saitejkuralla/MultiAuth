﻿using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace JWTtoken.Controllers
{
    /// <summary>
    /// Controller for weather forecast data.
    /// </summary>
    [ApiController]
    [Route("[controller]")]
    public class WeatherForecastController : ControllerBase
    {
        private static readonly string[] Summaries = new[]
        {
            "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
        };

        private readonly ILogger<WeatherForecastController> _logger;

        /// <summary>
        /// Initializes a new instance of the <see cref="WeatherForecastController"/> class.
        /// </summary>
        /// <param name="logger">The logger.</param>
        public WeatherForecastController(ILogger<WeatherForecastController> logger)
        {
            _logger = logger;
        }

        /// <summary>
        /// Retrieves weather forecast data for ServerA.
        /// </summary>
        /// <returns>The weather forecast data.</returns>
        [HttpGet("ServerA")]
        [Authorize]
        public IEnumerable<WeatherForecast> Get()
        {
            var rng = new Random();
            return Enumerable.Range(1, 5).Select(index => new WeatherForecast
            {
                Date = DateTime.Now.AddDays(index),
                TemperatureC = rng.Next(-20, 55),
                Summary = Summaries[rng.Next(Summaries.Length)]
            })
            .ToArray();
        }

        /// <summary>
        /// Retrieves weather forecast data for ServerB.
        /// </summary>
        /// <returns>The weather forecast data.</returns>
        [HttpGet("ServerB")]
        [Authorize(AuthenticationSchemes = "SecondJwtScheme")]
        public IEnumerable<WeatherForecast> GetServerB()
        {
            var rng = new Random();
            return Enumerable.Range(1, 5).Select(index => new WeatherForecast
            {
                Date = DateTime.Now.AddDays(index),
                TemperatureC = rng.Next(-20, 55),
                Summary = Summaries[rng.Next(Summaries.Length)]
            })
            .ToArray();
        }

        /// <summary>
        /// Retrieves weather forecast data for admins.
        /// </summary>
        /// <returns>An HTTP response indicating the success of the operation.</returns>
        [HttpGet("admin")]
        [Authorize(AuthenticationSchemes = "MultiAuthSchemes")]
        public IActionResult GetForAdmin()
        {
            return Ok("This is a Common Method that is only accessible by Admins");
        }
    }
}
