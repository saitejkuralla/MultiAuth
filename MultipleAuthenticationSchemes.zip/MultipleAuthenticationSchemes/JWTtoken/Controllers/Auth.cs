﻿using JWTtoken.Models;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using System;

namespace JWTAuthentication.Controllers
{
    /// <summary>
    /// Controller for authentication operations.
    /// </summary>
    [ApiController]
    [Route("[controller]")]
    public class AuthController : ControllerBase
    {
        /// <summary>
        /// Logs in a user and generates a default JWT token.
        /// </summary>
        /// <param name="user">The user information.</param>
        /// <returns>An HTTP response with the generated JWT token.</returns>
        [HttpPost("loginDefaultJwt")]
        public IActionResult LoginDefaultJwt([FromBody] User user)
        {
            var secretKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes("superSecretKey@1"));
            var signinCredentials = new SigningCredentials(secretKey, SecurityAlgorithms.HmacSha256);

            var tokenOptions = new JwtSecurityToken(
                issuer: "https://localhost:7208/",
                audience: "https://localhost:7208/",
                claims: new List<Claim>() { new Claim(ClaimTypes.Name, user.UserName) },
                expires: DateTime.Now.AddMinutes(30),
                signingCredentials: signinCredentials
            );

            var tokenString = new JwtSecurityTokenHandler().WriteToken(tokenOptions);

            return Ok(new { Token = tokenString });
        }

        /// <summary>
        /// Logs in a user and generates a second JWT token.
        /// </summary>
        /// <param name="user">The user information.</param>
        /// <returns>An HTTP response with the generated JWT token.</returns>
        [HttpPost("loginSecondJwt")]
        public IActionResult LoginSecondJwt([FromBody] User user)
        {
            var secretKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes("superSecretKey@2"));
            var signinCredentials = new SigningCredentials(secretKey, SecurityAlgorithms.HmacSha256);

            var tokenOptions = new JwtSecurityToken(
                issuer: "https://localhost:7209/",
                audience: "https://localhost:7208/",
                claims: new List<Claim>() { new Claim(ClaimTypes.Name, user.UserName) },
                expires: DateTime.Now.AddMinutes(30),
                signingCredentials: signinCredentials
            );

            var tokenString = new JwtSecurityTokenHandler().WriteToken(tokenOptions);

            return Ok(new { Token = tokenString });
        }
    }
}
