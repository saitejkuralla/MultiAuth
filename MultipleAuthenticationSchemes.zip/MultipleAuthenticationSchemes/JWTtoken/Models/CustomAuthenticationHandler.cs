﻿using JWTtoken.Services;
using Microsoft.AspNetCore.Authentication;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System.Security.Claims;
using System.Text.Encodings.Web;
using System.Threading.Tasks;

namespace JWTtoken.AuthenticationHandlers
{
    public class CustomAuthenticationHandler : AuthenticationHandler<CustomAuthSchemeOptions>
    {
        private readonly IAuthenticateService _authenticateService;

        public CustomAuthenticationHandler(
            IOptionsMonitor<CustomAuthSchemeOptions> options,
            ILoggerFactory loggerFactory,
            UrlEncoder encoder,
            ISystemClock clock,
            IAuthenticateService authenticateService)
            : base(options, loggerFactory, encoder, clock)
        {
            _authenticateService = authenticateService;
        }

        protected override async Task<AuthenticateResult> HandleAuthenticateAsync()
        {
            if (!Request.Headers.TryGetValue("Authorization", out var authorizationHeader))
                return AuthenticateResult.Fail("No AccessToken");

            var token = authorizationHeader.ToString().Replace("Bearer ", "");


            var user = await _authenticateService.Authenticate(token, null); 

            if (user == null)
                return AuthenticateResult.Fail("Invalid token");

            var claims = new[]
            {
                new Claim(ClaimTypes.Name, user.UserId.ToString()),
                new Claim(ClaimTypes.Role, user.Role)
            };

            var identity = new ClaimsIdentity(claims, Scheme.Name);
            var principal = new ClaimsPrincipal(identity);
            var ticket = new AuthenticationTicket(principal, Scheme.Name);

            return AuthenticateResult.Success(ticket);
        }
    }

    public class CustomAuthSchemeOptions : AuthenticationSchemeOptions
    {
    }
}
