﻿namespace JWTtoken.Models
{
    public class User
    {
      
        public string UserName { get; set; }
       
    }
}
