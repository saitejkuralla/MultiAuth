﻿using JWTtoken.Models;
using System.Threading.Tasks;

namespace JWTtoken.Services
{
    public interface IAuthenticateService
    {
        Task<User> Authenticate(string username, string password);
    }
}
